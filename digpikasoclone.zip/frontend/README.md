Frontend setup:
1. cd frontend
2. npm install
3. create a .env file based on ../.env.example and fill frontend vars
4. npm run dev
